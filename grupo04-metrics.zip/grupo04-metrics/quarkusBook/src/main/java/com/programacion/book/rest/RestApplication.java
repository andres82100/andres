package com.programacion.book.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath(value = "/")
public class RestApplication extends Application{

}
